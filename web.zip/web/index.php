<html>
    <head>
        <title>Monitoring Kualitas Air</title>
        <link rel="stylesheet" type="text/css" href="css2.css" />
    </head>
    <body>
        <!-------------------------------------------------- Navbar ------------------------------------------->
            <div class="div-navbar">
                <ul class="ul-navbar">
                    <li class="li-navbar">
                        <a href="#" class="a-navbar">Home</a>
                    </li>
                    <li class="li-navbar">
                        <a href="location.php" class="a-navbar">Location of Device</a>
                    </li>
                    <li class="li-navbar">
                        <a href="about.php" class="a-navbar">About Us</a>
                    </li>
                </ul>
            </div>
        <!-------------------------------------------------- Navbar Done ---------------------------------------------->

        <!--------------------------------------------------- Content ----------------------------------------------->
        <div class="text-judul-content"><p> Website Perangkat IoT Monitoring Kualitas Air
                                      (Studi Kasus: Danau Toba)</p>
        </div>

        <div class="text-isi-content"><p> Dibutuhkan sebuah system pemantauan untuk memoninitoring kualitas air danau
                                            dengan berdasarkan parameter yaitu suhu air, kekeruhan, kadar oksigen air dan pH.
                                            Sistem ini bertujuan untuk masyarakat mengetahui konsisi air sekitar Danau Toba.</p>
        </div>

        <!-- <div class="text-deskripsi-content"><p>Pastikan air yang anda gunakan layak untuk di konsumsi.</p>
                                     <p>Website ini merupakan sebuah layanan yang dapat digunakan untuk memantau kadar air danau toba
                                     pada beberapa tempat. Anda dapat mengetahui apakah air layak untuk di konsumsi atau tidak
                                     dengan melihat kadar Suhu, Kekeruhan, Ph dan juga Oksigen terlarut pada air. </p>
        </div> -->
            <!-- <div class="div-content-home">
                <ul class="ul-content-home">
                    <li class="li-content-home">
                        <a href="bulbul.php" class="a-content-home">Pantai Lumban Bul-Bul, Minggu ke-1 Februari 2023</a>
                    </li>
                    <li class="li-content-home">
                        <a href="pasput.php" class="a-content-home">Pantai Pasir Putih Porsea, Minggu ke-2 Februari 2023 </a>
                    </li>
                    <li class="li-content-home">
                        <a href="siregar.php" class="a-content-home">Siregar Aek Na Las, Minggu ke-3 Februari 2023 </a>
                    </li>
                    <li class="li-content-home">
                        <a href="lbs.php" class="a-content-home">Lumban Silintong, Minggu ke-4 Februari 2023</a>
                    </li>
                </ul>
            </div> -->
  
        <!--------------------------------------------------- Content Done ------------------------------------->

        <!------------------------------------------------------ Footer ------------------------------------------------>
            <!-- <div class="div-footer">
               <h1 class="footer">Copyright@EzriJeremi</h1>
            </div> -->
        <!------------------------------------------------------- Footer Done ----------------------------------------------->
    </body>
    <footer>
        <p>Copyright@Kelompok 12 TA D3TK 2020</p>
    </footer>
</html>
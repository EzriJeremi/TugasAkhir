<?php

    $host = "localhost";
    $user = "root";
    $pass = "";
    $database = "db_monitoring_kualitas_air";

    $koneksi = mysqli_connect($host, $user, $pass);
    if ($koneksi) {
        $buka=mysqli_select_db($koneksi, $database);
        // echo"database terhubung";
        if(!$buka){
            echo "database tidak terhubung";
        }
    }else{
        echo "mysql tidak terhubung";
    }

?>
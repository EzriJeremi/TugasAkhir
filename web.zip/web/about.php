<html>
    <head>
        <title>Monitoring Kualitas Air</title>
        <link rel="stylesheet" type="text/css" href="css2.css" />
        <link rel="stylesheet" type="text/css" href="css_about.css" />
        <link rel="stylesheet" href="bootstrap.min.css"> 


    </head>
    <body>
        <!------------------------------------------------ Navbar --------------------------------------------------------->
            <div class="div-navbar">
                <ul class="ul-navbar">
                    <li class="li-navbar">
                        <a href="index.php" class="a-navbar">Home</a>
                    </li>
                    <li class="li-navbar">
                        <a href="location.php" class="a-navbar">Location of Device</a>
                    </li>
                    <li class="li-navbar">
                        <a href="about.php" class="a-navbar">About Us</a>
                    </li>
                </ul>
            </div>
        <!---------------------------------------------- Navbar Done --------------------------------------------->

        <!------------------------------------------------ Content ------------------------------------------------>
        <div class="content-about">
            <h1>About Us</h1>
            <div class="content-about1">
                <div class="content-about2">
                    <div class="content-about3">
                        <img src="gambar/jeremi.jpeg" >
                    </div>
                    <h3>Ezri Jeremi</h3>
                    <h3> <a href="https://wa.me/message/I722MKDYTARMN1" class="a-jere" 0822-6089-1801> 0822-6089-1801</a></h3>
                </div>
                <div class="content-about2">
                    <div class="content-about3">
                        <img src="gambar/sopia.jpg" alt="our_team">
                    </div>
                    <h3>Shopia Sibarani</h3>
                    <h3>0896-2012-7902</h3>
                </div>
                    <div class="content-about2">
                    <div class="content-about3">
                        <img src="gambar/theo.jpg" >
                    </div>
                    <h3>Theo Sabrien Purba</h3>
                    <h3>0822-7238-8334</h3>
                </div>
                
            </div>
            <div class="content-about4">
                    <div class="bawah">
                    <p>Web ini merupakan project Tugas Akhir kami Kelompok 12 D3TK 2020 Institut Teknologi DEL, Jika ada masukan ataupun yang hendak ditayakan tolong hubungi kami melalui whatsup dengan click nomor telfon kami yang sudah tertera di atas.</p>
                    </div>
                </div> 
        </div>	


            <!-- <div class="div-content-about">
                <ul>
                    <li class="li-content-about">
                        <img src="gambar/jeremi.jpeg" class="gambar2" />
                            <span>Ezri Jeremi</span>
                            <span>IT DEL</span>
                            <a href="https://wa.me/message/I722MKDYTARMN1" target="_blank" class="a-jere">0822-6089-1801</a>
                    </li>
                </ul>
            </div> -->
        <!---------------------------------------------- Content Done ----------------------------------------------->

    </body>
    <footer>
        <p>Copyright@Kelompok 12 TA D3TK 2020</p>
    </footer>
</html>
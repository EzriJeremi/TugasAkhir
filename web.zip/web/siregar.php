<!-- Koneksi grafik -->
<?php
// Koneksi ke database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "db_monitoring_kualitas_air";

$conn = new mysqli($servername, $username, $password, $dbname);

// Query data dari tabel tb_siregar
$sql = "SELECT waktu, suhu, ntu, ph, do FROM tb_siregar";
$result = $conn->query($sql);

// Memproses data dari database
$waktu = array();
$suhu = array();
$ntu= array();
$ph= array();
$oksigen= array();
while($row = $result->fetch_assoc()) {
  $waktu[] = $row["waktu"];
  $suhu[] = $row["suhu"];
  $ntu[] = $row["ntu"];
  $ph[] = $row["ph"];
  $oksigen[] = $row["do"];
}

// Menutup koneksi ke database
$conn->close();
?>

<html>
    <head>
        <title>Monitoring Kualitas Air</title>
        <link rel="stylesheet" type="text/css" href="css2.css" />
        <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        <link rel="stylesheet" href="bootstrap.min.css"> 

    </head>
    <body>
        <!-------------------------------------------------- Navbar ------------------------------------------->
            <div class="div-navbar">
                <ul class="ul-navbar">
                    <li class="li-navbar">
                        <a href="index.php" class="a-navbar">Home</a>
                    </li>
                    <li class="li-navbar">
                        <a href="location.php" class="a-navbar">Location of Device</a>
                    </li>
                    <li class="li-navbar">
                        <a href="about.php" class="a-navbar">About Us</a>
                    </li>
                </ul>
            </div>
        <!-------------------------------------------------- Navbar Done ---------------------------------------------->

        <!--------------------------------------------------- Content-siregar ----------------------------------------------->
        <div class="div-content-bulbul">
        <h2 id="h2tabelsiregar" > Kondisi Air Siregar Aek na Las </h2>
            <table class = "tabel" border="1" width="50%" align="center">
                <tr bgcolor = "white">
                    <th>waktu</th>
                    <th>Suhu</th>
                    <th>Kekeruhan</th>
                    <th>pH</th>
                    <th>Oksigen</th>
                </tr>
                
                <?php
                        include "koneksi.php";
                        $query = mysqli_query ($koneksi,"Select * From tb_siregar order by id desc limit 1");
                        while($data = mysqli_fetch_array($query)){
                    ?>
                <tr bgcolor = "white">
                    <td><?php echo $data['waktu']; ?></td>
                    <td><?php echo $data['suhu']; ?> °C</td>
                    <td><?php echo $data['ntu']; ?> ntu</td>
                    <td><?php echo $data['ph']; ?></td>
                    <td><?php echo $data['do']; ?> mg/L</td>
                </tr>  
                <?php } ?>

                </table>
                <h2><a href="historisiregar.php" class="histori-siregar">History</a></h2>
        </div>

        <div class="container text-center">
            <div class="row" >
                <div style="width: 50%;" class="col-6 col-sm-3 " >
                    <canvas id="id-Chart-suhu-siregar"></canvas>
                </div>

                <script >
                    var waktu = <?php echo json_encode($waktu); ?>;
                    var suhu = <?php echo json_encode($suhu); ?>;

                    var ctx = document.getElementById('id-Chart-suhu-siregar').getContext('2d');
                    var ChartSuhuSiregar = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: waktu,
                            datasets: [{
                                label: 'Suhu (°C)',
                                data: suhu,
                                backgroundColor: 'white',
                                borderColor: 'rgba(255,99,132,1)',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            scales: {
                                yAxes: [{
                                    ticks: {
                                        beginAtZero:true
                                    }
                                }]
                            },

                        }
                    });
                </script>

                <div style="width: 50%;" class="col-6 col-sm-3" >
                    <canvas id="Chart-ntu-siregar"></canvas>
                </div>

                <script >
                    var waktu = <?php echo json_encode($waktu); ?>;
                    var ntu = <?php echo json_encode($ntu); ?>;

                    var ctx = document.getElementById('Chart-ntu-siregar').getContext('2d');
                    var ChartNtuSiregar = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: waktu,
                            datasets: [{
                                label: 'Kekeruhan (ntu)',
                                data: ntu,
                                backgroundColor: 'white',
                                borderColor: 'rgba(255,99,132,1)',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            scales: {
                                yAxes: [{
                                    ticks: {
                                        beginAtZero:true
                                    }
                                }]
                            },

                        }
                    });
                </script>

                <div class="w-100"></div>

                
                <div style="width: 50%;" class="col-6 col-sm-3">
                    <canvas id="Chart-ph-siregar"></canvas>
                </div>

                <script >
                    var waktu = <?php echo json_encode($waktu); ?>;
                    var ph = <?php echo json_encode($ph); ?>;

                    var ctx = document.getElementById('Chart-ph-siregar').getContext('2d');
                    var ChartPhSiregar = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: waktu,
                            datasets: [{
                                label: 'ph',
                                data: ph,
                                backgroundColor: 'white',
                                borderColor: 'rgba(255,99,132,1)',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            scales: {
                                yAxes: [{
                                    ticks: {
                                        beginAtZero:true
                                    }
                                }]
                            },

                        }
                    });
                </script>

                <div  style="width: 50%;" class="col-6 col-sm-3">
                    <canvas id="Chart-do-siregar"></canvas>
                </div>

                <script >
                    var waktu = <?php echo json_encode($waktu); ?>;
                    var oksigen = <?php echo json_encode($oksigen); ?>;

                    var ctx = document.getElementById('Chart-do-siregar').getContext('2d');
                    var ChartdoSiregar = new Chart(ctx, {
                        type: 'line',
                        data: {
                            labels: waktu,
                            datasets: [{
                                label: 'Do (mg/L)',
                                data: oksigen,
                                backgroundColor: 'white',
                                borderColor: 'rgba(255,99,132,1)',
                                borderWidth: 1
                            }]
                        },
                        options: {
                            scales: {
                                yAxes: [{
                                    ticks: {
                                        beginAtZero:true
                                    }
                                }]
                            },

                        }
                    });
                </script>
            </div>
        </div>

                <!-- <tr bgcolor = "whitesmoke">
                    <?php
                        include "koneksi.php";
                        $query = mysqli_query ($koneksi,"Select * From tb_siregar");
                        while($data = mysqli_fetch_array($query)){
                    ?>
                    <td><?php echo $data['ph']; ?></td>
                    <td><?php echo $data['oksigen']; ?></td>
                    <td><?php echo $data['kekeruhan']; ?></td>
                    <td><?php echo $data['suhu']; }?></td>
                </tr> -->
            
            <!-- <div class="div-content-siregar">
                <ul class="ul-content-siregar">
                    <h1 class="li-content-siregar">Suhu : 20^C</h1> 
                    <h1 class="li-content-siregar">pH : 7</h1>
                    <h1 class="li-content-siregar">Oksigen : 100</h1>
                    <h1 class="li-content-siregar">Kekeruhan : 50</h1>
                </ul>
            </div> -->
        <!--------------------------------------------------- Content Done ------------------------------------->

    </body>
    <footer>
        <p>Copyright@Kelompok 12 TA D3TK 2020</p>
    </footer>
</html>
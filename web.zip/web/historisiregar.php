<html>
    <head>
        <title>Monitoring Kualitas Air</title>
        <link rel="stylesheet" type="text/css" href="css2.css" />
    </head>
    <body>
        <!-------------------------------------------------- Navbar ------------------------------------------->
            <div class="div-navbar">
                <ul class="ul-navbar">
                    <li class="li-navbar">
                        <a href="index.php" class="a-navbar">Home</a>
                    </li>
                    <li class="li-navbar">
                        <a href="location.php" class="a-navbar">Location of Device</a>
                    </li>
                    <li class="li-navbar">
                        <a href="about.php" class="a-navbar">About Us</a>
                    </li>
                </ul>
            </div>
        <!-------------------------------------------------- Navbar Done ---------------------------------------------->

        <!--------------------------------------------------- Content-bulbul ----------------------------------------------->
        <div class="div-content-bulbul">
            <h2 id="h2tabelbulbul"> <a href="siregar.php">Kondisi Air Siregar Aek na Las </a></h2>
            <table class = "table" border="1" width="50%" align="center">
                <tr bgcolor = "white">
                    <th>waktu</th>
                    <th>suhu</th>
                    <th>ntu</th>
                    <th>ph</th>
                    <th>do</th>
                </tr>
                
            <?php
                include "koneksi.php";
                $query = mysqli_query ($koneksi,"Select * From tb_siregar");
                while($data = mysqli_fetch_array($query)){
            ?>
                <tr bgcolor = "whitesmoke">
                <td><?php echo $data['waktu']; ?></td>
                <td><?php echo $data['suhu']; ?></td>
                <td><?php echo $data['ntu']; ?></td>
                <td><?php echo $data['ph']; ?></td>
                <td><?php echo $data['do']; ?></td>
                </tr>
            <?php } ?>

            </table>
        </div>
                
                
        
            <!-- <table class="table-content-bulbul">
                <thead class="thead-content-bulbul">
                        <tr>
                            <th><h1 class="li-content-bulbul">Suhu </h1></th>
                            <th><h1 class="li-content-bulbul">pH </h1></th>
                            <th><h1 class="li-content-bulbul">Oksigen </h1></th>
                            <th><h1 class="li-content-bulbul">Kekeruhan </h1></th>
                        </tr>
                </thead>
                <tbody class="tbody-content-bulbul">
                    <tr>
                        <td>20</td>
                        <td>21</td>
                        <td>22</td>
                        <td>23</td>
                    </tr>
                </tbody>
            

            </table> -->
        <!--------------------------------------------------- Content Done ------------------------------------->

    </body>
    <footer>
        <p>Copyright@Kelompok 12 TA D3TK 2020</p>
    </footer>
</html>
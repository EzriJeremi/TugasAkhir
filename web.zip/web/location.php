<html>
    <head>
        <title>Monitoring Kualitas Air</title>
        <link rel="stylesheet" type="text/css" href="css2.css" />
    </head>
    <body>
        <!-- Navbar -->
            <div class="div-navbar">
                <ul class="ul-navbar">
                    <li class="li-navbar">
                        <a href="index.php" class="a-navbar">Home</a>
                    </li>
                    <li class="li-navbar">
                        <a href="location.php" class="a-navbar">Location of Device</a>
                    </li>
                    <li class="li-navbar">
                        <a href="about.php" class="a-navbar">About Us</a>
                    </li>
                </ul>
            </div>
        <!-- Navbar Done -->

        <!------------------------------------------------------ Content ------------------------------------------------>
        <div class="div-content-location">
            <ul class="ul-content-location">
                <li class="li-content-location">
                    <a href="bulbul.php" class="a-content-location">Pantai Lumban Bul-Bul</a>
                </li>
                <li class="li-content-location">
                    <a href="pasput.php" class="a-content-location">Pantai Pasir Putih Porsea</a>
                </li>
                <li class="li-content-location">
                    <a href="siregar.php" class="a-content-location">Siregar Aek Na Las</a>
                </li>
                <li class="li-content-location">
                    <a href="lbs.php" class="a-content-location">Lumban Silintong</a>
                </li>
            </ul>
            <!-- <img src="gambar/danau.JPG" class="gambar1"/> -->
        </div>
        <!----------------------------------------------------------- Content Done ------------------------------->
    </body>
    <footer>
        <p>Copyright@Kelompok 12 TA D3TK 2020</p>
    </footer>
</html>